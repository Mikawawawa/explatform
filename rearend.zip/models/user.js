const connection=require("./connect")

/**
 * Author: 
 * Date: 
 * Time: 
 * Description: 
 */
exports.login=async function login(id,password) {
    
}

/**
 * Author: 
 * Date: 
 * Time: 
 * Description: 
 */
exports.getPower=async function getPower(id){

}