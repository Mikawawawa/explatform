const connection=require("./connect")

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.getCourse=function(student_id){

}

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.getExp=function(course_id,student_id){

}

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.setReport=function(student_id,exp_id,article){

}