const connection=require("./connect")

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.getCourse=async function(id) {
    
}

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.getExp=async function(class_id){

}

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: 
 */
exports.getReport=async function(report_id){

}

/**
 * Author: 
 * Date: 
 * Time: 
 * Comment: grade需要在前面处理好，这里是实际要修改成的分数，
 * 包括action、report、preview属性，
 * 如果不修改某个值的话，要传进来原来的值
 */
exports.setGrade=async function(student_id,exp_id,grade){

}

/**
 * Author: 
 * Date: 
 * Time: 
 * Description: 
 */
exports.startExp=async function(classroom_id,class_id,process){

}